public interface IDraggableObjects3Nivel3
{

}
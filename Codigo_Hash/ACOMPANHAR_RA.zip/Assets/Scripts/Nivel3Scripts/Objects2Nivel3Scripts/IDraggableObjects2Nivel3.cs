public interface IDraggableObjects2Nivel3
{

}
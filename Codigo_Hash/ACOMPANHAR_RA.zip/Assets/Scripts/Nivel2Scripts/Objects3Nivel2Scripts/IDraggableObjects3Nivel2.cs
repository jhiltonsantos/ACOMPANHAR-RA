public interface IDraggableObjects3Nivel2
{

}
public interface IDraggableObjects2Nivel2
{

}
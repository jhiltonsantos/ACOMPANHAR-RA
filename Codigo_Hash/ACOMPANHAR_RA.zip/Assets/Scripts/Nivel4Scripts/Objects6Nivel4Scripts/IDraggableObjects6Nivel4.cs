public interface IDraggableObjects6Nivel4
{

}
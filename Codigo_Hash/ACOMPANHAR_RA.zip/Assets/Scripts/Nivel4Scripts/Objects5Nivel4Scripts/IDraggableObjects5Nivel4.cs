public interface IDraggableObjects5Nivel4
{

}
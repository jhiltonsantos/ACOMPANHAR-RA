public interface IDraggableObjects3Nivel4
{

}
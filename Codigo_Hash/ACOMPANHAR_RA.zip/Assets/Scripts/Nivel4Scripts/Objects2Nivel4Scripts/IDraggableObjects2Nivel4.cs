public interface IDraggableObjects2Nivel4
{

}
public interface IDraggableObjects4Nivel4
{

}